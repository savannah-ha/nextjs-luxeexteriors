import React from "react";
import ReactDOM from "react-dom/client";
import LuxeInvestorMicrosite from "./LuxeInvestorMicrosite.jsx";
import "./index.css";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <LuxeInvestorMicrosite />
  </React.StrictMode>
);
