import React from "react";
import { motion } from "framer-motion";
import { BookOpen, Award, Users, Sparkles } from "lucide-react";

export default function LuxeInvestorMicrosite() {
  const ogImage = "https://www.luxeexteriorsllc.com/images/showcase-home.webp";
  const logoPrimary = "/assets/logos/horizontal.png";
  const logoSecondary = "/assets/logos/LUXE Logo+Graphics - BG.png";
  const logoIcon = "/assets/logos/LUXE-icon.png";

  return (
    <div className="min-h-screen bg-[#faf9f7] text-[#222] font-sans antialiased">
      <header className="bg-white py-6 border-b border-gray-200 flex justify-center">
        <img src={logoPrimary} alt="LUXE Exteriors Primary Logo" className="h-12 w-auto" />
      </header>

      <section className="relative overflow-hidden bg-gradient-to-b from-[#1b1b1b] via-[#111] to-[#000] text-white">
        <div className="max-w-6xl mx-auto px-6 py-20">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.7 }}>
              <div className="inline-flex items-center gap-3 mb-4">
                <div className="bg-white/10 rounded-full p-2">
                  <Sparkles className="w-6 h-6 text-[#d4af37]" />
                </div>
                <span className="text-sm uppercase tracking-[0.15em] text-gray-300">Private Investor Preview</span>
              </div>

              <h1 className="text-4xl md:text-5xl font-bold leading-tight tracking-tight text-[#d4af37]">The Future of Home Renovation Has Arrived.</h1>

              <p className="mt-6 text-gray-300 max-w-xl leading-relaxed">
                LUXE Exterior Design is redefining the American home — blending clarity, craftsmanship, and concierge-level service in a $500B market. We invite visionary partners to join us as we reshape an industry ready for reinvention.
              </p>

              <div className="mt-8 flex flex-wrap gap-4">
                <a href="#book" className="bg-[#a74ed0] text-white font-semibold px-6 py-3 rounded-md shadow hover:bg-[#b768dd] transition">Book Your Private Preview</a>
                <a href="#deck" className="border border-[#a74ed0] text-[#a74ed0] px-6 py-3 rounded-md hover:bg-[#a74ed0]/10 transition">Request the Vision Deck</a>
              </div>
            </motion.div>

            <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.7 }} className="relative">
              <div className="rounded-2xl overflow-hidden shadow-2xl border border-white/10">
                <img src={ogImage} alt="Modern home exterior transformation" className="w-full h-96 object-cover" />
                <div className="absolute bottom-0 left-0 right-0 p-6 bg-gradient-to-t from-black/70 to-transparent">
                  <h3 className="font-semibold text-lg text-[#d4af37]">A Modern Estate Reimagined</h3>
                  <p className="text-sm text-gray-300">Precision meets beauty — the LUXE way.</p>
                </div>
              </div>
              <div className="mt-6 flex justify-center gap-6">
                <img src={logoSecondary} alt="LUXE Secondary Logo" className="h-10 w-auto" />
                <img src={logoIcon} alt="LUXE Icon Logo" className="h-10 w-auto" />
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      <main className="max-w-6xl mx-auto px-6 pb-20 -mt-12">
        <section className="bg-white rounded-2xl shadow-lg p-8">
          <h2 className="text-3xl font-bold text-[#d4af37]">The Opportunity</h2>
          <p className="mt-4 text-gray-700 leading-relaxed">
            Homeowners are done with high-pressure sales and cookie-cutter contractors. LUXE delivers transparency, education, and elevated design — giving clients the knowledge and confidence to make smart, inspired decisions.
          </p>
          <div className="grid sm:grid-cols-3 gap-6 mt-8">
            <div className="p-6 bg-[#faf9f7] rounded-lg border border-[#a74ed0]/20">
              <Award className="w-6 h-6 text-[#d4af37] mb-2" />
              <h4 className="font-semibold text-lg">$500B Market</h4>
              <p className="text-sm text-gray-600">An industry begging for modernization and trust.</p>
            </div>
            <div className="p-6 bg-[#faf9f7] rounded-lg border border-[#a74ed0]/20">
              <Users className="w-6 h-6 text-[#d4af37] mb-2" />
              <h4 className="font-semibold text-lg">Educated Homeowners</h4>
              <p className="text-sm text-gray-600">Demanding design, transparency, and authenticity.</p>
            </div>
            <div className="p-6 bg-[#faf9f7] rounded-lg border border-[#a74ed0]/20">
              <BookOpen className="w-6 h-6 text-[#d4af37] mb-2" />
              <h4 className="font-semibold text-lg">Education-First Model</h4>
              <p className="text-sm text-gray-600">Trust built through clarity and insight — not sales pressure.</p>
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t border-gray-200 py-8 bg-[#fffefc]">
        <div className="max-w-6xl mx-auto px-6 flex flex-col sm:flex-row justify-between items-center gap-4">
          <div>
            <h3 className="font-semibold text-lg text-[#d4af37]">LUXE Exterior Design</h3>
            <p className="text-sm text-gray-600">Redefining the art of home construction</p>
          </div>
          <div className="flex items-center gap-6">
            <a href="https://www.luxeexteriorsllc.com" target="_blank" rel="noreferrer" className="text-sm text-gray-600 hover:text-[#a74ed0]">luxeexteriorsllc.com</a>
            <a href="mailto:invest@luxeexteriorsllc.com" className="text-sm text-gray-600 hover:text-[#a74ed0]">invest@luxeexteriorsllc.com</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
