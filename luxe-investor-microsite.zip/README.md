Luxe Investor Microsite - Ready to deploy

How to use:
1. Unzip and open this folder.
2. Run `npm install` to install dependencies.
3. Run `npm run dev` to start a local dev server.
4. Run `npm run build` to produce a production build, or deploy directly to Vercel/Netlify.

Notes:
- The uploaded logo was copied into public/assets/logos/.
- Tailwind, Framer Motion and lucide-react are included as dependencies.
